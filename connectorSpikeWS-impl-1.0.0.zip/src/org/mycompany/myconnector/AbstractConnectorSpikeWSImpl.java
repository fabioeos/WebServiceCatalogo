package org.mycompany.myconnector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractConnectorSpikeWSImpl extends AbstractConnector {

	protected final String OUTPUT1_OUTPUT_PARAMETER = "Output1";

	protected final void setOutput1(java.util.LinkedList output1) {
		setOutputParameter(OUTPUT1_OUTPUT_PARAMETER, output1);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
