/**
 * 
 */
package org.mycompany.myconnector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.bonitasoft.engine.connector.ConnectorException;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class ConnectorSpikeWSImpl extends AbstractConnectorSpikeWSImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
	
		//TODO execute your business logic here 
		LinkedList<String> list = new LinkedList<String>();
		URL url;
        HttpURLConnection conn;
        BufferedReader rd;
        String line;
	    String result = "";
	    try {
	       url = new URL("http://localhost:65170/SpikeWebServiceRest.svc/GetProductList/");
	       conn = (HttpURLConnection) url.openConnection();
	       conn.setRequestMethod("GET");
	       rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
	       while ((line = rd.readLine()) != null) {
	          result += line;
	       }
  	       rd.close();
	    } catch (IOException e) {
	       e.printStackTrace();
	    } catch (Exception e) {
	       e.printStackTrace();
	    }
	
	    DocumentBuilder db;
		try {
			db = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
		    is.setCharacterStream(new StringReader(result));
		    Document doc = (Document) db.parse(is);
		    
		    NodeList nodes = ((org.w3c.dom.Document) doc).getElementsByTagName("Name");
		    
		    for (int i = 0; i < nodes.getLength(); i++) {
				list.add(nodes.item(i).toString());
			}
		    
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    
		//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
		setOutput1(list);
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
