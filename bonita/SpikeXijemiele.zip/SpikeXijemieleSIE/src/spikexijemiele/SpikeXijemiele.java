/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spikexijemiele;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Ruijormar
 */
public class SpikeXijemiele {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Cliente> clientes = new ArrayList<>();
        Cliente c1 = new Cliente("Spear Legstrong", "Rua do pojo", "123456789", "spear@cena.com");
        try {
            clientes = readXml();
            addCliente(clientes, c1);
            createXml(clientes);
        } catch (ParserConfigurationException | TransformerException | SAXException | IOException ex) {
            Logger.getLogger(SpikeXijemiele.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void createXml(ArrayList<Cliente> clientes) throws ParserConfigurationException, TransformerConfigurationException, TransformerException, IOException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.newDocument();
        Element root = doc.createElement("clientes");
        doc.appendChild(root);
        
        Element clienteElement;
        Element nomeElement;
        Element moradaElement;
        Element numContElement;
        Element emailElement;
        
        for(Cliente c : clientes){
            clienteElement = doc.createElement("cliente");
            nomeElement = doc.createElement("nome");
            nomeElement.appendChild(doc.createTextNode(c.nome));
            moradaElement = doc.createElement("morada");
            moradaElement.appendChild(doc.createTextNode(c.morada));
            numContElement = doc.createElement("numeroDeContribuinte");
            numContElement.appendChild(doc.createTextNode(c.numCont));
            emailElement = doc.createElement("email");
            emailElement.appendChild(doc.createTextNode(c.email));
            clienteElement.appendChild(nomeElement);
            clienteElement.appendChild(moradaElement);
            clienteElement.appendChild(numContElement);
            clienteElement.appendChild(emailElement);
            root.appendChild(clienteElement);
        }
        
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        
        //indentação
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        
        
        DOMSource source = new DOMSource(doc);
        File f = new File("C:\\clientesBagates.xml");
        StreamResult result = new StreamResult(f);
        if(!f.isFile()){
            f.createNewFile();
        }
        transformer.transform(source, result);
    }
    
    private static ArrayList<Cliente> readXml() throws ParserConfigurationException, SAXException, IOException{
        File fXmlFile = new File("C:\\clientes.xml");
        
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
        ArrayList clientes = new ArrayList();
        String nome;
        String morada;
        String numcont;
        String email;
        
        Node clients = doc.getElementsByTagName("clientes").item(0);
        NodeList clientNodes = clients.getChildNodes();
        
        for(int i = 0; i < clientNodes.getLength(); i++){
            Node clientNode = clientNodes.item(i);
            if(clientNode.getNodeType() == Node.ELEMENT_NODE){
                Element clientElement = (Element) clientNode;
                nome = clientElement.getElementsByTagName("nome").item(0).getTextContent();
                morada = clientElement.getElementsByTagName("morada").item(0).getTextContent();
                numcont = clientElement.getElementsByTagName("numeroDeContribuinte").item(0).getTextContent();
                email = clientElement.getElementsByTagName("email").item(0).getTextContent();
                Cliente c = new Cliente(nome, morada, numcont, email);
                clientes.add(c);
            }
        }
        return clientes;
    }
    
    private static void addCliente(ArrayList<Cliente> clientes, Cliente c){
        Boolean found = false;
        for(Cliente cliente : clientes){
            if(c.numCont.equals(cliente.numCont)){
                found = true;
                if(!c.morada.equals(cliente.morada)){
                    cliente.morada = c.morada;
                }
                if(!c.email.equals(cliente.email)){
                    cliente.email = c.email;
                }
            }
        }
        if(!found){
            clientes.add(c);
        }
    }
}
