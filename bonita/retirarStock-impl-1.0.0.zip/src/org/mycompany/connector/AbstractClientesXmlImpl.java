package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractClientesXmlImpl extends AbstractConnector {

	protected final static String NOME_INPUT_PARAMETER = "nome" ;
	protected final static String MORADA_INPUT_PARAMETER = "morada" ;
	protected final static String NUMCONT_INPUT_PARAMETER = "numCont" ;
	protected final static String EMAIL_INPUT_PARAMETER = "email" ;
	protected final String NEW_OUTPUT_PARAMETER = "new" ;

	protected final java.lang.String getNome() {
		 return (java.lang.String) getInputParameter(NOME_INPUT_PARAMETER);
	}

	protected final java.lang.String getMorada() {
		 return (java.lang.String) getInputParameter(MORADA_INPUT_PARAMETER);
	}

	protected final java.lang.String getNumCont() {
		 return (java.lang.String) getInputParameter(NUMCONT_INPUT_PARAMETER);
	}

	protected final java.lang.String getEmail() {
		 return (java.lang.String) getInputParameter(EMAIL_INPUT_PARAMETER);
	}

	protected final void setNew(java.lang.Boolean new) {
		 setOutputParameter(NEW_OUTPUT_PARAMETER , new );
	}

}

	@Override
	public void validateInputParameters() throws ConnectorValidationException{
		try{ 
		getNome();
	 }catch (ClassCastException cce) {
		 throw new ConnectorValidationException("nome type is invalid") ;
		  }
	try{ 
		getMorada();
	 }catch (ClassCastException cce) {
		 throw new ConnectorValidationException("morada type is invalid") ;
		  }
	try{ 
		getNumCont();
	 }catch (ClassCastException cce) {
		 throw new ConnectorValidationException("numCont type is invalid") ;
		  }
	try{ 
		getEmail();
	 }catch (ClassCastException cce) {
		 throw new ConnectorValidationException("email type is invalid") ;
		  }
	
		}
