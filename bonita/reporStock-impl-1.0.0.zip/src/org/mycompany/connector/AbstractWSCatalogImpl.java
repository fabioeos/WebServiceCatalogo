package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractWSCatalogImpl extends AbstractConnector {

	protected final String PRODUTOS_OUTPUT_PARAMETER = "produtos";

	protected final void setProdutos(java.util.HashMap produtos) {
		setOutputParameter(PRODUTOS_OUTPUT_PARAMETER, produtos);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

	}

}
