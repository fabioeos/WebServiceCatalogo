/**
 * 
 */
package org.mycompany.connector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class Verifica_disponibilidadeImpl extends
		AbstractVerifica_disponibilidadeImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		HashMap<String,String> disponibilidade = getDisponibilidade();
		HashMap<String,ArrayList<String>> encomenda = getEncomenda();
		HashMap<String,String> paraPedir = new HashMap<String,String>();
		Boolean disponivel = true;
		
		for(Entry<String, ArrayList<String>> entryEncomenda : encomenda.entrySet()) {
		    String keyEncomenda = entryEncomenda.getKey();
		    ArrayList<String> valueEncomenda = entryEncomenda.getValue();
		    String qtd = valueEncomenda.get(1);
		    for(Entry<String, String> entryDisponibilidade : disponibilidade.entrySet()) {
			    String keyDisponibilidade = entryDisponibilidade.getKey();
			    String valueDisponibilidade = entryDisponibilidade.getValue();
			    if(keyDisponibilidade.equals(keyEncomenda) && Integer.valueOf(qtd) > Integer.valueOf(valueDisponibilidade)){
					disponivel = false;
					int pedir = Integer.valueOf(qtd) - Integer.valueOf(valueDisponibilidade);
					paraPedir.put(keyEncomenda, String.valueOf(pedir));
				}
			}

		}
		
		//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
		setDisponivel(disponivel);
		setParaPedir(paraPedir);
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
