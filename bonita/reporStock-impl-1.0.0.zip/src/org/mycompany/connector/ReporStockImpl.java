/**
 * 
 */
package org.mycompany.connector;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map.Entry;

import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class ReporStockImpl extends AbstractReporStockImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		HashMap<String,String> enc = getParaPedir();
		
		
        try {
        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			
            Connection conn = DriverManager.getConnection("jdbc:sqlserver://fe52c266-fc7e-4970-a1ea-a4ba01660b51.sqlserver.sequelizer.com"
                    + ";user=aoymqucwfvjkkkzn;"
                    + "password=6dJj7PXYtNU6m6W4VoKaaKQjZwywywSCmTW2FnhtShj7chPpbAKmW5FuuzsHpzz6;"
                    + "database=dbfe52c266fc7e4970a1eaa4ba01660b51");
            
             PreparedStatement ps = conn.prepareStatement("UPDATE Product " +
                            "SET stock = (select stock from Product where ProductCode = ?)" + " + ? " +
                            "WHERE ProductCode = ?;");
 
             for (Entry<String, String> entry : enc.entrySet()){
            	// set the preparedstatement parameters
     	        ps.setString(1,entry.getKey());
     	        ps.setInt(2,Integer.valueOf(entry.getValue()));
     	        ps.setString(3,entry.getKey());
     	        // call executeUpdate to execute our sql update statement
     	        ps.executeUpdate();  	 
             }
	                  
	        ps.close();
	        
        } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
