package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractReporStockImpl extends AbstractConnector {

	protected final static String PARAPEDIR_INPUT_PARAMETER = "paraPedir";

	protected final java.util.HashMap getParaPedir() {
		return (java.util.HashMap) getInputParameter(PARAPEDIR_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getParaPedir();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("paraPedir type is invalid");
		}

	}

}
