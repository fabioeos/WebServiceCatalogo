package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractRetirarStockImpl extends AbstractConnector {

	protected final static String ENCOMENDA_INPUT_PARAMETER = "encomenda";

	protected final java.util.HashMap getEncomenda() {
		return (java.util.HashMap) getInputParameter(ENCOMENDA_INPUT_PARAMETER);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getEncomenda();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("encomenda type is invalid");
		}

	}

}
