/**
 * 
 */
package org.mycompany.connector;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.bonitasoft.engine.connector.ConnectorException;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class WSCatalogImpl extends AbstractWSCatalogImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		HashMap<String, ArrayList<String>> list = new HashMap<String, ArrayList<String>>();
		URL url;
		HttpURLConnection conn;
		BufferedReader rd;
		String line;
		String result = "";
		Document doc = null;
		try {
			url = new URL("http://webservicecatalog.apphb.com/ServiceProductManager.svc/rest/GetCatalog/");
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			while ((line = rd.readLine()) != null) {
				result += line;
			}
			rd.close();
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();  
			DocumentBuilder builder;  
			builder = factory.newDocumentBuilder();  
			doc = builder.parse( new InputSource( new StringReader( result ) ) );

			NodeList nodes = doc.getElementsByTagName("ProductSimple");

			for (int i = 0; i < nodes.getLength(); i++) {
				NodeList node = (NodeList) nodes.item(i);
				String productCode ="";
				String price ="";
				String name="";
				for(int j=0;j<node.getLength();j++) {
					Node n = node.item(j);

					if (n.getNodeType() == Node.ELEMENT_NODE){
						if(n.getNodeName().equals("Name")){
							name = n.getTextContent();
						}else if(n.getNodeName().equals("Price")){
							price = n.getTextContent();
						}else if(n.getNodeName().equals("ProductCode")){
							productCode = n.getTextContent();
						}
					}
					if(!name.isEmpty() && !price.isEmpty() && !productCode.isEmpty()){
						ArrayList<String> aux = new ArrayList<String>();
						aux.add(name);
						aux.add(price);
						list.put(productCode,aux);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		setProdutos(list);

	}

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server

	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server

	}

}
