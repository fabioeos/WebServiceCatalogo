package org.mycompany.connector;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractVerifica_disponibilidadeImpl extends
		AbstractConnector {

	protected final static String DISPONIBILIDADE_INPUT_PARAMETER = "disponibilidade";
	protected final static String ENCOMENDA_INPUT_PARAMETER = "encomenda";
	protected final String DISPONIVEL_OUTPUT_PARAMETER = "disponivel";

	protected final java.util.LinkedList getDisponibilidade() {
		return (java.util.LinkedList) getInputParameter(DISPONIBILIDADE_INPUT_PARAMETER);
	}

	protected final java.util.LinkedList getEncomenda() {
		return (java.util.LinkedList) getInputParameter(ENCOMENDA_INPUT_PARAMETER);
	}

	protected final void setDisponivel(java.lang.Boolean disponivel) {
		setOutputParameter(DISPONIVEL_OUTPUT_PARAMETER, disponivel);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getDisponibilidade();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"disponibilidade type is invalid");
		}
		try {
			getEncomenda();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("encomenda type is invalid");
		}

	}

}
