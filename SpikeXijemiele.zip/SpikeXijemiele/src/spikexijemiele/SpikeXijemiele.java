/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package spikexijemiele;

import java.io.File;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author Ruijormar
 */
public class SpikeXijemiele {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Spear Legstrong", "Rua do pojo", "123456789", "spear@cenas.com");
        Cliente c2 = new Cliente("Bagates Aropen", "Rua do hearthstein", "987654321", "lord@arena.hs");
        Cliente c3 = new Cliente("Engernheiro Nabiças", "Outra rua do hearthstein", "192837465", "engnabicas@cenas.com");
        ArrayList<Cliente> clientes = new ArrayList<>();
        clientes.add(c1);
        clientes.add(c2);
        clientes.add(c3);
        try {
            createXml(clientes);
        } catch (ParserConfigurationException | TransformerException ex) {
            Logger.getLogger(SpikeXijemiele.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private static void createXml(ArrayList<Cliente> clientes) throws ParserConfigurationException, TransformerConfigurationException, TransformerException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.newDocument();
        Element root = doc.createElement("clientes");
        doc.appendChild(root);
        
        Element clienteElement;
        Element nomeElement;
        Element moradaElement;
        Element numContElement;
        Element emailElement;
        
        for(Cliente c : clientes){
            clienteElement = doc.createElement("cliente");
            nomeElement = doc.createElement("nome");
            nomeElement.appendChild(doc.createTextNode(c.nome));
            moradaElement = doc.createElement("morada");
            moradaElement.appendChild(doc.createTextNode(c.morada));
            numContElement = doc.createElement("numeroDeContribuinte");
            numContElement.appendChild(doc.createTextNode(c.numCont));
            emailElement = doc.createElement("email");
            emailElement.appendChild(doc.createTextNode(c.email));
            clienteElement.appendChild(nomeElement);
            clienteElement.appendChild(moradaElement);
            clienteElement.appendChild(numContElement);
            clienteElement.appendChild(emailElement);
            root.appendChild(clienteElement);
        }
        
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        
        //indentação
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        
        
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File("C:\\clientes.xml"));
        transformer.transform(source, result);
    }
    
}
