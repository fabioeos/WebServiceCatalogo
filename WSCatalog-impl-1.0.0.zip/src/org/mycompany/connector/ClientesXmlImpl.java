/**
 * 
 */
package org.mycompany.connector;

import org.bonitasoft.engine.connector.ConnectorException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.mycompany.connector.ClientesXmlImpl.Cliente;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class ClientesXmlImpl extends AbstractClientesXmlImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		String nome = getNome();
		String morada = getMorada();
		String numCont = getNumCont();
		String email = getEmail();
		Boolean output = false;
		
		ArrayList<Cliente> clientes = new ArrayList<Cliente>();
		
		Cliente novo = new Cliente(nome, morada, numCont, email);
		
		try{
			readXml();
			output = addCliente(clientes, novo);
			createXml(clientes);
		} catch (Exception ex) {
            Logger.getLogger(ClientesXmlImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		setOutputParameter("new", output);
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}
	
	private void createXml(ArrayList<Cliente> clientes) throws ParserConfigurationException, TransformerConfigurationException, TransformerException, IOException {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        
        Document doc = dBuilder.newDocument();
        Element root = doc.createElement("clientes");
        doc.appendChild(root);
        
        Element clienteElement;
        Element nomeElement;
        Element moradaElement;
        Element numContElement;
        Element emailElement;
        
        for(Cliente c : clientes){
            clienteElement = doc.createElement("cliente");
            nomeElement = doc.createElement("nome");
            nomeElement.appendChild(doc.createTextNode(c.nome));
            moradaElement = doc.createElement("morada");
            moradaElement.appendChild(doc.createTextNode(c.morada));
            numContElement = doc.createElement("numeroDeContribuinte");
            numContElement.appendChild(doc.createTextNode(c.numCont));
            emailElement = doc.createElement("email");
            emailElement.appendChild(doc.createTextNode(c.email));
            clienteElement.appendChild(nomeElement);
            clienteElement.appendChild(moradaElement);
            clienteElement.appendChild(numContElement);
            clienteElement.appendChild(emailElement);
            root.appendChild(clienteElement);
        }
        
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        
        //indentação
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        
        
        DOMSource source = new DOMSource(doc);
        File f = new File("C:\\clientes.xml");
        StreamResult result = new StreamResult(f);
        if(!f.isFile()){
            f.createNewFile();
        }
        transformer.transform(source, result);
    }
    
    private ArrayList<Cliente> readXml() throws ParserConfigurationException, SAXException, IOException{
        File fXmlFile = new File("C:\\clientes.xml");
        
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
        ArrayList<Cliente> clientes = new ArrayList<Cliente>();
        String nome;
        String morada;
        String numcont;
        String email;
        
        Node clients = doc.getElementsByTagName("clientes").item(0);
        NodeList clientNodes = clients.getChildNodes();
        
        for(int i = 0; i < clientNodes.getLength(); i++){
            Node clientNode = clientNodes.item(i);
            if(clientNode.getNodeType() == Node.ELEMENT_NODE){
                Element clientElement = (Element) clientNode;
                nome = clientElement.getElementsByTagName("nome").item(0).getTextContent();
                morada = clientElement.getElementsByTagName("morada").item(0).getTextContent();
                numcont = clientElement.getElementsByTagName("numeroDeContribuinte").item(0).getTextContent();
                email = clientElement.getElementsByTagName("email").item(0).getTextContent();
                Cliente c = new Cliente(nome, morada, numcont, email);
                clientes.add(c);
            }
        }
        return clientes;
    }
    
    private boolean addCliente(ArrayList<Cliente> clientes, Cliente c){
        boolean found = false;
        for(Cliente cliente : clientes){
            if(c.numCont.equals(cliente.numCont)){
                found = true;
                if(!c.morada.equals(cliente.morada)){
                    cliente.morada = c.morada;
                }
                if(!c.email.equals(cliente.email)){
                    cliente.email = c.email;
                }
            }
        }
        if(!found){
            clientes.add(c);
            return true;
        }else{
        	return false;
        }
    }
    
    public class Cliente {
        String nome;
        String morada;
        String numCont;
        String email;

        public Cliente(String nome, String morada, String numCont, String email) {
            this.nome = nome;
            this.morada = morada;
            this.numCont = numCont;
            this.email = email;
        }
    }
    
}



